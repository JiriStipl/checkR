#' Check Age Content
#'
#' Ensures age values make sense within a specified range
#' and optionally displays statistics and a histogram.
#'
#' @param data_age Numeric vector of ages.
#' @param plot_histogram Logical. If TRUE, plots a histogram (default: TRUE).
#' @param range Numeric vector of length 2 specifying the valid range (default: c(0, 120)).
#' @param force_summary Logical. If TRUE, prints summary statistics even if the range check fails (default: FALSE).
#' @importFrom ggplot2 ggplot aes geom_histogram theme_minimal labs
#' @importFrom crayon underline magenta green red
#' @return TRUE if all checks pass, FALSE otherwise.
#' @export
checkAge <- function(data_age,
                     plot_histogram = TRUE,
                     range = c(0, 120),
                     force_summary = FALSE) {
  # Ensure valid range argument
  if (length(range) != 2 ||
      !is.numeric(range) || range[1] >= range[2]) {
    stop("Argument 'range' must be a numeric vector of length 2 with range[1] < range[2].")
  }

  # Handle empty vector
  if (length(data_age) == 0) {
    stop("The input 'data_age' is an empty vector.")
  }

  # Check for valid range
  out_of_range <- data_age < range[1] | data_age > range[2]
  all_within_range <- !any(out_of_range)

  # Print statistics
  cat(crayon::underline("Age Range Summary\n"))
  cat(crayon::magenta("Min age: \t\t"), round(min(data_age), 2), "\n")
  cat(crayon::green("5th percentile: \t"),
      round(quantile(data_age, 0.05), 2),
      "\n")
  cat(crayon::red("Median age: \t\t"), round(median(data_age), 2), "\n")
  cat(crayon::green("95th percentile: \t"),
      round(quantile(data_age, 0.95), 2),
      "\n")
  cat(crayon::magenta("Max age: \t\t"), round(max(data_age), 2), "\n")

  # Warn if out-of-range values exist
  if (!all_within_range) {
    warning(
      "Values outside the range [",
      range[1],
      ", ",
      range[2],
      "] found at indices: ",
      paste(which(out_of_range), collapse = ", "),
      ". Values: ",
      paste(data_age[out_of_range], collapse = ", "),
      "."
    )

    # Plot histogram if requested
    if (plot_histogram) {
      print(
        ggplot2::ggplot(data.frame(Age = data_age), ggplot2::aes(x = Age)) +
          ggplot2::geom_histogram(
            fill = "black",
            color = "white",
            binwidth = 0.25
          ) +
          ggplot2::theme_minimal() +
          ggplot2::labs(title = "Histogram of Ages", x = "Age", y = "Frequency")
      )
    }

    if (!force_summary)
      return(FALSE)
  }


  return(TRUE)
}
