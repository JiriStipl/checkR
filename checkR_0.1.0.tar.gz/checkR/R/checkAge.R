#' Check Age Content
#'
#' Ensures age values make sense (e.g., within the range 0-120)
#' and optionally displays statistics and a histogram.
#'
#' @param data_age Numeric vector of ages.
#' @param plot_histogram Logical. If TRUE, plots a histogram (default: TRUE).
#' @importFrom ggplot2 ggplot aes geom_histogram theme_minimal labs
#' @importFrom crayon underline magenta green red
#' @return TRUE if all checks pass, FALSE otherwise.
#' @export
checkAge <- function(data_age, plot_histogram = TRUE) {
  # Check for valid range
  out_of_range <- data_age < 0 | data_age > 120
  if (any(out_of_range)) {
    warning("Values outside 0-120 range at indices: ",
            paste(which(out_of_range), collapse = ", "),
            ". Values: ", paste(data_age[out_of_range], collapse = ", "), ".")
    return(FALSE)
  }

  # Print statistics
  cat(crayon::underline("Age range\n"))
  cat(crayon::magenta("Min age: \t\t"), round(min(data_age), 2), "\n")
  cat(crayon::green("5th percentile: \t"), round(quantile(data_age, 0.05), 2), "\n")
  cat(crayon::red("Median age: \t\t"), round(median(data_age), 2), "\n")
  cat(crayon::green("95th percentile: \t"), round(quantile(data_age, 0.95), 2), "\n")
  cat(crayon::magenta("Max age: \t\t"), round(max(data_age), 2), "\n")

  # Plot histogram if requested
  if (plot_histogram) {
    ggplot2::ggplot(data.frame(Age = data_age), ggplot2::aes(x = Age)) +
      ggplot2::geom_histogram(fill = "black", color = "white", binwidth = 0.25) +
      ggplot2::theme_minimal() +
      ggplot2::labs(title = "Histogram of Ages", x = "Age", y = "Frequency")
  }

  return(TRUE)
}
