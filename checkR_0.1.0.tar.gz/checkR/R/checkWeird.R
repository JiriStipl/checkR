#' Check for Non-standard Values in a Vector
#'
#' Validates whether the provided vector contains only standard numerical values.
#'
#' @param vector Numeric vector to check.
#' @return TRUE if no non-standard values are found, FALSE otherwise.
#' @export
checkWeird <- function(vector) {
  # Validate numeric vector
  if (!is.numeric(vector)) {
    stop("vector is not a numerical vector.")
    return(FALSE)
  }

  # Check for non-standard values
  invalid_values <- is.na(vector) | is.nan(vector) | is.infinite(vector)
  if (any(invalid_values)) {
    warning("Non-standard values found at indices: ",
            paste(which(invalid_values), collapse = ", "),
            ". Values: ", paste(vector[invalid_values], collapse = ", "), ".")
    return(FALSE)
  }
  return(TRUE)
}
